package myapp;


public class Computer
    extends Product
{


    private String  _cpu;


    public String getCpu()
    {
        return _cpu;
    }


    public void setCpu( String cpu )
    {
        _cpu = cpu;
    }


}
